package lk.sliita.colourpicker;

public class Constants {

}
