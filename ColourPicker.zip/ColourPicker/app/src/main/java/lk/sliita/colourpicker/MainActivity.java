package lk.sliita.colourpicker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button play;
    EditText name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        play = findViewById(R.id.btn_play);
        name = findViewById(R.id.et_player_name);

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onButtonTapped(v);
            }
        });

    }
    public void onButtonTapped(View v){
        String player = name.getText().toString();
        if(player.isEmpty()){
            name.setError("Enter Player Name");
            return;
        }
        Intent intent = new Intent(this,GameGUI.class);
        intent.putExtra("player Name",player);
        startActivity(intent);
    }

}